// Paste the full SSC Daily Checklist PWA React code here (from canvas)
import React, { useEffect, useState } from "react";

const DEFAULT_TROPHY_GOAL = 150;
const STORAGE_KEY = "ssc_checklist_v1";
const LAST_RESET_KEY = "ssc_checklist_last_reset";

const defaultTasks = [
  { id: "gk_video", title: "GK video complete", xp: 30 },
  { id: "gk_pdf", title: "1 GK pdf revise", xp: 20 },
  { id: "eng_video", title: "English video complete", xp: 30 },
  { id: "eng_pdf", title: "1 English pdf revise", xp: 20 },
  { id: "calc_practice", title: "15 min calc practise", xp: 25 },
];

function todayISO() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

export default function App() {
  const [tasks, setTasks] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn("Failed reading local storage", e);
    }
    return defaultTasks.map((t) => ({ ...t, completed: false }));
  });

  const [trophyGoal, setTrophyGoal] = useState(() => {
    const g = localStorage.getItem("ssc_trophy_goal");
    return g ? Number(g) : DEFAULT_TROPHY_GOAL;
  });

  useEffect(() => {
    const last = localStorage.getItem(LAST_RESET_KEY);
    const today = todayISO();
    if (last !== today) {
      setTasks((prev) => prev.map((t) => ({ ...t, completed: false })));
      localStorage.setItem(LAST_RESET_KEY, today);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem("ssc_trophy_goal", String(trophyGoal));
  }, [trophyGoal]);

  const toggle = (id) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const totalXP = tasks.reduce((s, t) => s + (t.completed ? t.xp : 0), 0);
  const progressPercent = Math.max(0, Math.min(100, Math.round((totalXP / trophyGoal) * 100)));

  const addTask = (title, xp) => {
    const id = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "_")}_${Date.now()}`;
    setTasks((prev) => [...prev, { id, title, xp: Number(xp), completed: false }]);
  };

  const removeTask = (id) => {
    if (!confirm("Remove this task?")) return;
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const resetToday = () => {
    if (!confirm("Reset today's completions?")) return;
    setTasks((prev) => prev.map((t) => ({ ...t, completed: false })));
    localStorage.setItem(LAST_RESET_KEY, todayISO());
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6 flex flex-col items-center">
      <div className="w-full max-w-2xl">
        <header className="mb-6">
          <h1 className="text-2xl font-semibold">SSC Daily Checklist ✅</h1>
          <p className="text-sm text-slate-600">Mark tasks done to earn XP.</p>
        </header>

        <section className="mb-4 bg-white shadow rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-sm text-slate-500">Total XP today</div>
              <div className="text-xl font-bold">{totalXP} XP</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-500">Trophy goal</div>
              <div className="text-lg font-medium">{trophyGoal} XP</div>
            </div>
          </div>

          <div className="w-full bg-slate-200 h-4 rounded-full overflow-hidden mb-2">
            <div
              className="h-4 rounded-full transition-all duration-400"
              style={{ width: `${progressPercent}%`, background: "linear-gradient(90deg,#f59e0b,#ef4444)" }}
            />
          </div>
          <div className="text-xs text-slate-600 flex justify-between">
            <span>{progressPercent}% toward trophy</span>
            <span>{totalXP}/{trophyGoal} XP</span>
          </div>

          <div className="mt-3 flex gap-2 items-center">
            <label className="flex items-center gap-2 text-sm">
              <span>Set goal</span>
              <input
                type="number"
                min={10}
                className="w-24 p-1 border rounded"
                value={trophyGoal}
                onChange={(e) => setTrophyGoal(Number(e.target.value || 0))}
              />
            </label>
            <button className="ml-auto px-3 py-1 rounded shadow bg-slate-100" onClick={resetToday}>Reset today</button>
          </div>
        </section>

        <section className="mb-6 bg-white shadow rounded-lg p-4">
          <h2 className="font-semibold mb-3">Tasks</h2>
          <ul className="space-y-2">
            {tasks.map((t) => (
              <li key={t.id} className="flex items-center justify-between p-2 border rounded">
                <label className="flex items-center gap-3">
                  <input type="checkbox" checked={t.completed} onChange={() => toggle(t.id)} />
                  <div>
                    <div className="font-medium">{t.title}</div>
                    <div className="text-xs text-slate-500">{t.xp} XP</div>
                  </div>
                </label>
                <button className="text-sm px-2 py-1 rounded text-red-600" onClick={() => removeTask(t.id)}>Remove</button>
              </li>
            ))}
          </ul>
        </section>

      </div>
    </div>
  );
}
